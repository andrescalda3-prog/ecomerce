(() => {
  const format = n => '$' + new Intl.NumberFormat('es-UY').format(n);
  function init(root) {
    if (!root || root.dataset.initialized) return;
    root.dataset.initialized = 'true';
    const demo = root.dataset.demo === 'true';
    const form = root.querySelector('.purchase-form');
    const qty = root.querySelector('#MopaQuantity');
    const options = [...root.querySelectorAll('.pack input')];
    const selected = () => options.find(i => i.checked);
    const dialog = root.querySelector('[data-demo-dialog]');
    const key = 'casa-facil-beige-demo-v3';
    let cart = null;
    function update() {
      const option = selected(); if (!option) return;
      const price = demo ? Number(option.dataset.unit) : Number(option.dataset.unit) / 100;
      const old = demo ? Number(option.dataset.old) : Number(option.dataset.compareCents) / 100;
      root.querySelector('[data-price]').textContent = demo ? format(price) : option.dataset.money;
      root.querySelector('[data-sticky-price]').textContent = demo ? format(price) : option.dataset.money;
      const compare = root.querySelector('[data-compare]'), saving = root.querySelector('[data-saving]');
      compare.hidden = saving.hidden = !(old > price);
      compare.textContent = demo ? format(old) : option.dataset.compareMoney;
      if (old > price) saving.textContent = Math.round((old - price) * 100 / old) + '% OFF';
      const add = root.querySelector('[data-add]');
      if (!demo) {
        add.disabled = option.dataset.available !== 'true';
        add.textContent = add.disabled ? 'Agotado' : 'Agregar a mi bolsa ↗';
        const url = new URL(location.href); url.searchParams.set('variant', option.value); history.replaceState({}, '', url);
        if (option.dataset.photo) { const image = root.querySelector('#ProductHero'); image.src = option.dataset.photo; image.removeAttribute('srcset'); }
      }
    }
    function persist() { try { localStorage.setItem(key, JSON.stringify(cart)); } catch (_) {} }
    function renderCart() {
      const body = root.querySelector('[data-cart-body]'); body.replaceChildren();
      if (!cart) { const empty = document.createElement('p'); empty.textContent = 'Tu bolsa de prueba está vacía.'; body.append(empty); return; }
      const row = document.createElement('div'); row.className = 'cart-demo-line';
      const image = document.createElement('img'); image.src = root.querySelector('#ProductHero').src; image.alt = 'Mopa spray beige';
      const text = document.createElement('div'), title = document.createElement('h3'); title.textContent = cart.label;
      const detail = document.createElement('p'); detail.textContent = cart.quantity + ' kit(s) · ' + format(cart.unit) + ' por kit';
      const remove = document.createElement('button'); remove.type='button'; remove.className='remove-item'; remove.textContent='Quitar';
      remove.addEventListener('click',()=>{cart=null;persist();renderCart();});
      text.append(title,detail,remove);row.append(image,text);
      const total = document.createElement('div'); total.className='cart-subtotal';
      const label = document.createElement('span'); label.textContent='Subtotal de ejemplo';
      const value = document.createElement('strong'); value.textContent=format(cart.unit * cart.quantity);
      total.append(label,value);body.append(row,total);
    }
    function openCart() { renderCart(); if (!dialog.open) dialog.showModal(); }
    root.addEventListener('click',event=>{
      const thumb=event.target.closest('.thumbs [data-photo]');
      if(thumb){const image=root.querySelector('#ProductHero');image.src=thumb.dataset.photo;image.removeAttribute('srcset');root.querySelectorAll('.thumbs [data-photo]').forEach(b=>b.setAttribute('aria-pressed',String(b===thumb)));}
      if(event.target.closest('[data-sticky-buy]')){form.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'center'});setTimeout(()=>selected()?.focus({preventScroll:true}),200);}
      if(event.target.closest('[data-close]')) dialog.close();
    });
    options.forEach(option=>option.addEventListener('change',update));
    qty.addEventListener('input',()=>{if(Number(qty.value)>10)qty.value='10';});
    if(demo){
      if(new URLSearchParams(location.search).get('kit') === 'combo') options.find(i=>i.value==='Combo mopa y 2 paños multiuso').checked = true;
      try { const saved=JSON.parse(localStorage.getItem(key)); const valid={'Mopa spray beige':990,'Combo mopa y 2 paños multiuso':1190}; if(saved && Object.hasOwn(valid,saved.label) && Number.isInteger(saved.quantity) && saved.quantity>=1 && saved.quantity<=10) cart={label:saved.label,unit:valid[saved.label],quantity:saved.quantity}; }catch(_){}
      form.addEventListener('submit',event=>{event.preventDefault();if(!form.reportValidity())return;const option=selected();cart={label:option.value,unit:Number(option.dataset.unit),quantity:Number(qty.value)};persist();root.querySelector('[data-status]').textContent='Agregado a tu bolsa de demostración.';openCart();});
      document.querySelectorAll('.bag-link').forEach(link=>link.addEventListener('click',event=>{if(!root.isConnected)return;event.preventDefault();openCart();}));
    }
    update();
  }
  init(document.querySelector('[data-mopa-product]'));
  document.addEventListener('shopify:section:load',event=>init(event.target.querySelector('[data-mopa-product]')));
})();
