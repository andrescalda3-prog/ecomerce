document.addEventListener('click', (event) => {
  const thumb = event.target.closest('[data-gallery]');
  if (!thumb) return;
  const image = document.getElementById(thumb.dataset.gallery)?.querySelector('img');
  if (image) { image.src = thumb.dataset.src; image.removeAttribute('srcset'); }
});
document.addEventListener('change', (event) => {
  if (!event.target.matches('[data-variant]')) return;
  const option = event.target.selectedOptions[0];
  const section = event.target.closest('.product-layout');
  section.querySelector('[data-price]').textContent = option.dataset.price;
  section.querySelector('[data-compare]')?.remove();
  const button = section.querySelector('[data-add]');
  button.disabled = option.dataset.available !== 'true';
  button.textContent = button.disabled ? 'Agotado' : 'Agregar a la bolsa ↗';
  const image = section.querySelector('.main-image img');
  if (image && option.dataset.image) { image.src = option.dataset.image; image.removeAttribute('srcset'); }
  const url = new URL(location.href); url.searchParams.set('variant', option.value); history.replaceState({}, '', url);
});
