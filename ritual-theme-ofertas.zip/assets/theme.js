document.addEventListener('click', (event) => {
  const thumb = event.target.closest('[data-gallery]');
  if (!thumb) return;
  const image = document.getElementById(thumb.dataset.gallery)?.querySelector('img');
  if (image) { image.src = thumb.dataset.src; image.removeAttribute('srcset'); }
});
document.addEventListener('change', (event) => {
  if (!event.target.matches('[data-variant]')) return;
  const option = event.target.selectedOptions[0];
  const section = event.target.closest('.product-layout');
  section.querySelector('[data-price]').textContent = option.dataset.price;
  section.querySelector('[data-compare]')?.remove();
  const button = section.querySelector('[data-add]');
  button.disabled = option.dataset.available !== 'true';
  button.textContent = button.disabled ? 'Agotado' : 'Agregar a la bolsa ↗';
  const image = section.querySelector('.main-image img');
  if (image && option.dataset.image) { image.src = option.dataset.image; image.removeAttribute('srcset'); }
  const url = new URL(location.href); url.searchParams.set('variant', option.value); history.replaceState({}, '', url);
});

// Isolated demo cart: never calls Shopify cart or checkout APIs.
(() => {
  function initDemo(root) {
    if (!root || root.dataset.initialized) return;
    root.dataset.initialized = 'true';
    const money = value => '$' + new Intl.NumberFormat('es-UY').format(value);
    const dialog = root.querySelector('[data-demo-cart]');
    const key = 'ritual-cacao-demo-v1';
    let quantity = 1, cart = null;
    try {
      const saved = JSON.parse(localStorage.getItem(key));
      if (saved && [1,2,3].includes(saved.pack) && Number.isInteger(saved.quantity) && saved.quantity > 0 && saved.quantity <= 10) {
        cart = {pack:saved.pack, quantity:saved.quantity, unit:({1:1192,2:2086,3:2682})[saved.pack]};
      }
    } catch (_) { /* Demo remains usable when storage is unavailable. */ }
    function persist() { try { localStorage.setItem(key, JSON.stringify(cart)); } catch (_) {} }
    const selected = () => root.querySelector('input[name="demo-pack"]:checked');
    function update() {
      const option = selected();
      root.querySelector('[data-demo-price]').textContent = money(Number(option.dataset.total) * quantity);
      root.querySelector('[data-demo-compare]').textContent = money(Number(option.dataset.compare) * quantity);
      root.querySelector('[data-demo-saving]').textContent = 'AHORRÁS ' + option.dataset.discount + '%';
      root.querySelector('[data-demo-quantity]').textContent = quantity;
      root.querySelector('[data-demo-qty="-1"]').disabled = quantity <= 1;
      root.querySelector('[data-demo-qty="1"]').disabled = quantity >= 10;
      root.querySelectorAll('.demo-pack').forEach(label => label.classList.toggle('selected', label.contains(option)));
      root.querySelector('[data-demo-feedback]').textContent = '';
    }
    function renderCart() {
      const content = root.querySelector('[data-demo-cart-content]');
      const image = root.querySelector('#DemoHero').getAttribute('src');
      content.replaceChildren();
      if (!cart) {
        const empty = document.createElement('p'); empty.textContent = 'Tu bolsa de ejemplo está vacía.'; content.append(empty);
      } else {
        // Only validated numeric state and bundled image URLs enter this markup.
        const row = document.createElement('div'); row.className = 'demo-cart-line';
        const img = document.createElement('img'); img.src = image; img.alt = 'Ritual Cacao';
        const copy = document.createElement('div');
        const title = document.createElement('h3'); title.textContent = 'Ritual Cacao Blend';
        const info = document.createElement('p'); info.textContent = cart.quantity + ' pack(s) de ' + cart.pack + ' frasco(s) · ' + (cart.quantity * cart.pack) + ' frasco(s) en total';
        const price = document.createElement('p'); price.textContent = money(cart.unit) + ' por pack';
        const remove = document.createElement('button'); remove.type = 'button'; remove.className = 'demo-remove'; remove.textContent = 'Quitar producto';
        remove.addEventListener('click', () => { cart = null; persist(); renderCart(); });
        copy.append(title,info,price,remove); row.append(img,copy);
        const total = document.createElement('div'); total.className = 'demo-cart-total';
        const label = document.createElement('span'); label.textContent = 'Subtotal de ejemplo';
        const amount = document.createElement('strong'); amount.textContent = money(cart.unit * cart.quantity);
        total.append(label,amount); content.append(row,total);
      }
    }
    function openCart() { renderCart(); if (!dialog.open) dialog.showModal(); }
    root.querySelectorAll('[data-demo-close]').forEach(button => button.addEventListener('click', () => dialog.close()));
    dialog.addEventListener('click', event => { if (event.target === dialog && event.clientX < dialog.getBoundingClientRect().left) dialog.close(); });
    root.addEventListener('change', event => { if (event.target.matches('input[name="demo-pack"]')) update(); });
    root.addEventListener('click', event => {
      const thumb = event.target.closest('[data-demo-image]');
      if (thumb) {
        const hero = root.querySelector('#DemoHero'); hero.src = thumb.dataset.demoImage; hero.alt = thumb.dataset.alt;
        root.querySelectorAll('[data-demo-image]').forEach(button => { button.classList.toggle('active', button === thumb); button.setAttribute('aria-pressed', String(button === thumb)); });
      }
      const qty = event.target.closest('[data-demo-qty]');
      if (qty) { quantity = Math.max(1, Math.min(10, quantity + Number(qty.dataset.demoQty))); update(); }
      if (event.target.closest('[data-demo-add]')) {
        const option = selected();
        cart = {pack:Number(option.value), quantity, unit:Number(option.dataset.total)}; persist();
        root.querySelector('[data-demo-feedback]').textContent = 'Agregado a tu bolsa de demostración.'; openCart();
      }
    });
    document.querySelectorAll('.cart-link').forEach(link => link.addEventListener('click', event => { if (!root.isConnected) return; event.preventDefault(); openCart(); }));
    update();
  }
  initDemo(document.querySelector('[data-demo-shop]'));
  document.addEventListener('shopify:section:load', event => initDemo(event.target.querySelector('[data-demo-shop]')));
})();
